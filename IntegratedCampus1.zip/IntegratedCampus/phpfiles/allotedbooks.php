<!DOCTYPE html>
<html>
<head>
    <title>Allotted Books</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2>Allotted Books</h2>

<table>
    <tr>
        <th>Book ID</th>
        <th>Hall Ticket Number</th>
        <th>Full Name</th>
        <th>Course ID</th>
        <th>Allotment Date</th>
        <th>Return Date</th>
        <th>Action</th>
    </tr>

<?php
// Database connection
$conn = oci_connect("INTEGRATEDCAMPUS", "12345", "localhost/XE");

if (!$conn) {
    $e = oci_error();
    die("Connection failed: " . $e['message']);
}

// Query to retrieve allotted books with fullname and COURSENAME from students table
$sql = "SELECT ab.BOOKID, ab.HALLTICKETNUMBER, s.fullname AS FULLNAME, s.coursename AS COURSENAME, ab.ALLOT_DATE, ab.RETURN_DATE
        FROM allotedbooks ab
        JOIN students s ON ab.HALLTICKETNUMBER = s.hallticketnumber
        WHERE ab.RETURN_DATE IS NULL"; // Only select books that have not been returned

$stmt = oci_parse($conn, $sql);

if (!$stmt) {
    $e = oci_error($conn);
    die("Query preparation failed: " . $e['message']);
}

// Execute the statement
if (oci_execute($stmt)) {
    while ($row = oci_fetch_assoc($stmt)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['BOOKID'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['HALLTICKETNUMBER'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['FULLNAME'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['COURSENAME'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['ALLOT_DATE'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['RETURN_DATE'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>";
        echo "<form method='post' action=''>";
        echo "<input type='hidden' name='bookid' value='" . htmlspecialchars($row['BOOKID'], ENT_QUOTES, 'UTF-8') . "'>";
        echo "<button type='submit' name='return'>Return</button>";
        echo "</form>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    $e = oci_error($stmt);
    die("Query execution failed: " . $e['message']);
}

oci_free_statement($stmt);
oci_close($conn);

// Handle return button click
if (isset($_POST['return'])) {
    $bookid = $_POST['bookid'];
    $returnDate = date('Y-m-d'); // Current date

    // Update RETURN_DATE in the database
    $conn = oci_connect("INTEGRATEDCAMPUS", "12345", "localhost/XE");

    if (!$conn) {
        $e = oci_error();
        die("Connection failed: " . $e['message']);
    }

    $updateSql = "UPDATE allotedbooks SET RETURN_DATE = TO_DATE(:returnDate, 'YYYY-MM-DD') WHERE BOOKID = :bookid";
    $stmt = oci_parse($conn, $updateSql);
    oci_bind_by_name($stmt, ":returnDate", $returnDate);
    oci_bind_by_name($stmt, ":bookid", $bookid);

    if (oci_execute($stmt)) {
        echo "<script>alert('Book returned successfully.')</script>";
        echo "<script>window.location.href = 'your_page_url';</script>"; // Redirect to refresh page
    } else {
        $e = oci_error($stmt);
        echo "Error updating RETURN_DATE: " . htmlspecialchars($e['message'], ENT_QUOTES, 'UTF-8');
    }

    oci_free_statement($stmt);
    oci_close($conn);
}
?>
</table>

</body>
</html>
