<!DOCTYPE html>
<html>
<head>
    <title>Mess Bills</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2>View and Pay Mess Bills</h2>

<form method="post" action="">
    <label for="month">Select Month:</label>
    <select id="month" name="month">
        <option value="January">January</option>
        <option value="February">February</option>
        <option value="March">March</option>
        <option value="April">April</option>
        <option value="May">May</option>
        <option value="June">June</option>
        <option value="July">July</option>
        <option value="August">August</option>
        <option value="September">September</option>
        <option value="October">October</option>
        <option value="November">November</option>
        <option value="December">December</option>
    </select>
    <button type="submit" name="submit">Get Bills</button>
</form>

<?php
if (isset($_POST['submit'])) {
    $selectedMonth = $_POST['month'];

    // Database connection
    $conn = oci_connect("INTEGRATEDCAMPUS", "12345", "localhost/XE");

    if (!$conn) {
        $e = oci_error();
        die("Connection failed: " . $e['message']);
    }

    $sql = "SELECT s.hallticketnumber, s.fullname, m.fees
            FROM students s
            JOIN monthly_bills m ON s.hallticketnumber = m.hallticketnumber
            WHERE m.month = :month";
    
    $stmt = oci_parse($conn, $sql);
    oci_bind_by_name($stmt, ":month", $selectedMonth);
    oci_execute($stmt);

    echo "<h3>Mess Bills for $selectedMonth</h3>";
    echo "<table>";
    echo "<tr><th>Hall Ticket Number</th><th>Student Name</th><th>Mess Bill</th><th>Action</th></tr>";

    while ($row = oci_fetch_assoc($stmt)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['HALLTICKETNUMBER'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['FULLNAME'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['FEES'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>
                <form method='post' action=''>
                    <input type='hidden' name='hallticketnumber' value='" . htmlspecialchars($row['HALLTICKETNUMBER'], ENT_QUOTES, 'UTF-8') . "'>
                    <input type='hidden' name='month' value='" . htmlspecialchars($selectedMonth, ENT_QUOTES, 'UTF-8') . "'>
                    <input type='hidden' name='fees' value='" . htmlspecialchars($row['FEES'], ENT_QUOTES, 'UTF-8') . "'>
                    <button type='submit' name='pay'>Paid</button>
                </form>
              </td>";
        echo "</tr>";
    }

    echo "</table>";

    oci_free_statement($stmt);
    oci_close($conn);
}

if (isset($_POST['pay'])) {
    $hallticketnumber = $_POST['hallticketnumber'];
    $month = $_POST['month'];
    $fees = $_POST['fees'];
    $paidDate = date('Y-m-d');

    // Database connection
    $conn = oci_connect("INTEGRATEDCAMPUS", "12345", "localhost/XE");

    if (!$conn) {
        $e = oci_error();
        die("Connection failed: " . $e['message']);
    }

    $sql_insert = "INSERT INTO paid_bills (hallticketnumber, month, fees, date_paid) VALUES (:hallticketnumber, :month, :fees, TO_DATE(:date_paid, 'YYYY-MM-DD'))";
    $stmt_insert = oci_parse($conn, $sql_insert);
    oci_bind_by_name($stmt_insert, ":hallticketnumber", $hallticketnumber);
    oci_bind_by_name($stmt_insert, ":month", $month);
    oci_bind_by_name($stmt_insert, ":fees", $fees);
    oci_bind_by_name($stmt_insert, ":date_paid", $paidDate);

    if (oci_execute($stmt_insert)) {
        // Delete the row from monthly_bills after marking it as paid
        $sql_delete = "DELETE FROM monthly_bills WHERE hallticketnumber = :hallticketnumber AND month = :month";
        $stmt_delete = oci_parse($conn, $sql_delete);
        oci_bind_by_name($stmt_delete, ":hallticketnumber", $hallticketnumber);
        oci_bind_by_name($stmt_delete, ":month", $month);

        if (oci_execute($stmt_delete)) {
            echo "Payment recorded and bill deleted successfully.";
        } else {
            $e = oci_error($stmt_delete);
            echo "Error deleting bill: " . htmlspecialchars($e['message'], ENT_QUOTES, 'UTF-8');
        }
    } else {
        $e = oci_error($stmt_insert);
        echo "Error recording payment: " . htmlspecialchars($e['message'], ENT_QUOTES, 'UTF-8');
    }

    oci_free_statement($stmt_insert);
    oci_free_statement($stmt_delete);
    oci_close($conn);
}
?>

</body>
</html>
