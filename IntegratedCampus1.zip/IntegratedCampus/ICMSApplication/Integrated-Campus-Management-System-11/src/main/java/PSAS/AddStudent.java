package PSAS;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import java.sql.*;

import users.StudentService;

@Controller
public class AddStudent {

    @GetMapping("/")
    public String error(@ModelAttribute StudentService users) {
        
        return "redirect:/error.html";
    }

    @PostMapping("/students")
    public String Addstudent(@ModelAttribute StudentService users, Model model) {
        String url = "jdbc:oracle:thin:@localhost:1521:XE";
        String dbusername = "INTEGRATEDCAMPUS";
        String dbpassword = "12345";

        Connection conn = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establish database connection
            conn = DriverManager.getConnection(url, dbusername, dbpassword);
            System.out.println("Database connection established");

            // Check if table exists and create if it does not
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT table_name FROM all_tables WHERE table_name = 'STUDENTS'");
            if (!rs.next()) {
                String createTableQuery = "CREATE TABLE Students (" +
                        "hallTicketNumber VARCHAR2(50) PRIMARY KEY, " +
                        "fullName VARCHAR2(100), " +
                        "phoneNumber VARCHAR2(15), " +
                        "emailAddress VARCHAR2(100), " +
                        "courseId VARCHAR2(50), " +
                        "courseName VARCHAR2(100), " +
                        "yearOfJoining NUMBER, " +
                        "currentYear VARCHAR2(10)" +
                        ")";
                stmt.execute(createTableQuery);
                System.out.println("Table Students created");
            }

            // Prepare SQL statement for insertion
            String query = "INSERT INTO Students (hallTicketNumber, fullName, phoneNumber, emailAddress, courseId, courseName, yearOfJoining, currentYear) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, users.gethallTicketNumber());
            preparedStatement.setString(2, users.getfullName());
            preparedStatement.setString(3, users.getphoneNumber());
            preparedStatement.setString(4, users.getemailAddress());
            preparedStatement.setString(5, users.getcourseId());
            preparedStatement.setString(6, users.getcourseName());
            preparedStatement.setInt(7, users.getyearOfJoining());
            preparedStatement.setString(8, users.getcurrentYear());

            // Execute the insertion
            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                model.addAttribute("message", "Data entered successfully!");
                return "redirect:/AdminHome.html";
            } else {
                model.addAttribute("error", "Data entry failed.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "An error occurred: " + e.getMessage());
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        

        return "redirect:/AdminHome.html";
    }
}
