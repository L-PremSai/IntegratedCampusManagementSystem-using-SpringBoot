package PSAS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegratedCampusManagementSystem11Application {

	public static void main(String[] args) {
		SpringApplication.run(IntegratedCampusManagementSystem11Application.class, args);
	}

}
