package PSAS;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.stereotype.Controller;


import java.sql.*;



//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.*;

import users.Users;


@Controller
public class loginusers{
	
	@GetMapping("/error")
	public String error(@ModelAttribute Users user) {
		
		return "redirect:/error.html";
		
		
		
	}
	

	
	@PostMapping("/login")
	public String Logins(@ModelAttribute Users user) {
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		String dbusername="INTEGRATEDCAMPUS";
		String dbpassword="12345";
		
		
		try {
            //Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn = DriverManager.getConnection(url, dbusername, dbpassword);
            System.out.println("Database connection established");
            String query = "SELECT * FROM ADMINLOGS WHERE EMAIL=? AND PASSWORD=?";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, user.getEmail());
            preparedStatement.setString(2, user.getPassword_ad());
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                return "redirect:/AdminHome.html";
            } else {
                
                return "redirect:/error.html";
                
            }
		
		
		
	}catch (SQLException e) {
            e.printStackTrace();
        }
		return "redirect:/login.html";
}
}