package PSAS;
import java.math.BigDecimal;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

@Controller
public class UploadController {

    private static final Logger logger = Logger.getLogger(UploadController.class.getName());

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/uploadExcel")
    public String uploadExcelForm() {
        return "uploadExcelForm";
    }

    @PostMapping("/uploadExcel")
    public String handleFileUpload(@RequestParam("fileUpload") MultipartFile file, Model model) {
        try (InputStream inputStream = file.getInputStream()) {
            Workbook workbook = new XSSFWorkbook(inputStream);
            Sheet sheet = workbook.getSheetAt(0);

            for (Row row : sheet) {
                // Skip the header row
                if (row.getRowNum() == 0) {
                    continue;
                }

                String hallTicketNumber = getCellValueAsString(row.getCell(0));
                String fullName = getCellValueAsString(row.getCell(1));
                String phoneNumber = getCellValueAsString(row.getCell(2));
                String emailAddress = getCellValueAsString(row.getCell(3));
                String courseId = getCellValueAsString(row.getCell(4));
                String courseName = getCellValueAsString(row.getCell(5));
                String yearOfJoining = getCellValueAsString(row.getCell(6));
                String currentYear = getCellValueAsString(row.getCell(7));

                logger.info("Row data: " + hallTicketNumber + ", " + fullName + ", " + phoneNumber + ", " + emailAddress + ", " + courseId + ", " + courseName + ", " + yearOfJoining + ", " + currentYear);

                if (!recordExists(hallTicketNumber)) {
                    String sql = "INSERT INTO students (hallticketnumber, fullname, phonenumber, emailaddress, courseid, coursename, yearofjoining, currentyear) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    int rowsAffected = jdbcTemplate.update(sql, hallTicketNumber, fullName, phoneNumber, emailAddress, courseId, courseName, yearOfJoining, currentYear);

                    if (rowsAffected > 0) {
                        logger.info("Inserted row: " + hallTicketNumber);
                    } else {
                        logger.warning("Failed to insert row: " + hallTicketNumber);
                    }
                } else {
                    logger.warning("Duplicate row: " + hallTicketNumber);
                }
            }

            workbook.close();
            model.addAttribute("message", "File uploaded and data saved successfully!");

        } catch (Exception e) {
            model.addAttribute("message", "Failed to upload file and save data: " + e.getMessage());
            logger.log(Level.SEVERE, "Error processing file", e);
        }

        return "uploadExcelForm";
    }

    private String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return "";
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    return BigDecimal.valueOf(cell.getNumericCellValue()).toPlainString();
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return cell.getCellFormula();
            case BLANK:
                return "";
            default:
                return "";
        }
    }

    private boolean recordExists(String hallTicketNumber) {
        String sql = "SELECT COUNT(*) FROM students WHERE hallticketnumber = ?";
        int count = jdbcTemplate.queryForObject(sql, new Object[]{hallTicketNumber}, Integer.class);
        return count > 0;
    }
}
