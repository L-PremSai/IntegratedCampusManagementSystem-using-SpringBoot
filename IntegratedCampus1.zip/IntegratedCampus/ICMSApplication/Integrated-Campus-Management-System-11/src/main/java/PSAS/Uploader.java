package PSAS;

import java.math.BigDecimal;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class Uploader {

    private static final Logger logger = Logger.getLogger(Uploader.class.getName());

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/messexcel")
    public String uploadExcelForm() {
        return "uploadExcelForm";
    }

    @PostMapping("/messexcel")
    public String handleFileUpload(@RequestParam("fileUpload") MultipartFile file, Model model) {
        try (InputStream inputStream = file.getInputStream();
             Workbook workbook = new XSSFWorkbook(inputStream)) {

            Sheet sheet = workbook.getSheetAt(0);

            for (Row row : sheet) {
                // Skip the header row
                if (row.getRowNum() == 0) {
                    continue;
                }

                String hallTicketNumber = getCellValueAsString(row.getCell(0));
                String month = getCellValueAsString(row.getCell(1));
                Double fees = getCellValueAsDouble(row.getCell(2));

                logger.info("Row data: " + hallTicketNumber + ", " + month + ", " + fees);

                if (!recordExists(hallTicketNumber)) {
                    String sql = "INSERT INTO monthly_bills (hallticketnumber, month, fees) VALUES (?, ?, ?)";
                    int rowsAffected = jdbcTemplate.update(sql, hallTicketNumber, month, fees);

                    if (rowsAffected > 0) {
                        logger.info("Inserted row: " + hallTicketNumber);
                    } else {
                        logger.warning("Failed to insert row: " + hallTicketNumber);
                    }
                } else {
                    logger.warning("Duplicate row: " + hallTicketNumber);
                }
            }

            model.addAttribute("message", "File uploaded and data saved successfully!");

        } catch (Exception e) {
            model.addAttribute("message", "Failed to upload file and save data: " + e.getMessage());
            logger.log(Level.SEVERE, "Error processing file", e);
        }

        return "uploadExcelForm";
    }

    private String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return "";
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    return BigDecimal.valueOf(cell.getNumericCellValue()).toPlainString();
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return cell.getCellFormula();
            case BLANK:
                return "";
            default:
                return "";
        }
    }

    private Double getCellValueAsDouble(Cell cell) {
        if (cell == null) {
            return 0.0;
        }
        switch (cell.getCellType()) {
            case NUMERIC:
                return cell.getNumericCellValue();
            case STRING:
                try {
                    return Double.valueOf(cell.getStringCellValue());
                } catch (NumberFormatException e) {
                    logger.warning("Failed to parse string to double: " + cell.getStringCellValue());
                    return 0.0;
                }
            default:
                return 0.0;
        }
    }

    private boolean recordExists(String hallTicketNumber) {
        String sql = "SELECT COUNT(*) FROM monthly_bills WHERE hallticketnumber = ?";
        int count = jdbcTemplate.queryForObject(sql, new Object[]{hallTicketNumber}, Integer.class);
        return count > 0;
    }
}
