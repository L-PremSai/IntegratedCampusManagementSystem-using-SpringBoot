package PSAS;

import java.io.InputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;

@Controller
public class Uploadhostler {

    private static final Logger logger = Logger.getLogger(Uploadhostler.class.getName());

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/uploadHostler")
    public String uploadExcelForm() {
        return "uploadExcelForm";
    }

    @PostMapping("/uploadHostler")
    public String handleFileUpload(@RequestParam("fileUpload") MultipartFile file, Model model) {
        try (InputStream inputStream = file.getInputStream()) {
            Workbook workbook = new XSSFWorkbook(inputStream);
            Sheet sheet = workbook.getSheetAt(0);

            SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");

            for (Row row : sheet) {
                // Skip the header row
                if (row.getRowNum() == 0) {
                    continue;
                }

                String hallTicketNumber = getCellValueAsString(row.getCell(0));
                String hostelName = getCellValueAsString(row.getCell(1));
                String joiningDate = getCellValueAsString(row.getCell(2));

                logger.info("Row data: " + hallTicketNumber + ", " + hostelName + ", " + joiningDate);

                if (!recordExists(hallTicketNumber)) {
                    String sql = "INSERT INTO hostelers (hallticketnumber, hostelname, joiningdate) VALUES (?, ?, ?)";
                    int rowsAffected = jdbcTemplate.update(sql, hallTicketNumber, hostelName, joiningDate);

                    if (rowsAffected > 0) {
                        logger.info("Inserted row: " + hallTicketNumber);
                    } else {
                        logger.warning("Failed to insert row: " + hallTicketNumber);
                    }
                } else {
                    logger.warning("Duplicate row: " + hallTicketNumber);
                }
            }

            workbook.close();
            model.addAttribute("message", "File uploaded and data saved successfully!");

        } catch (Exception e) {
            model.addAttribute("message", "Failed to upload file and save data: " + e.getMessage());
            logger.log(Level.SEVERE, "Error processing file", e);
        }

        return "uploadExcelForm";
    }

    private String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return "";
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    Date date = cell.getDateCellValue();
                    return new SimpleDateFormat("dd-MMM-yy").format(date);
                } else {
                    return BigDecimal.valueOf(cell.getNumericCellValue()).toPlainString();
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return cell.getCellFormula();
            case BLANK:
                return "";
            default:
                return "";
        }
    }

    private boolean recordExists(String hallTicketNumber) {
        String sql = "SELECT COUNT(*) FROM hostelers WHERE hallticketnumber = ?";
        int count = jdbcTemplate.queryForObject(sql, new Object[]{hallTicketNumber}, Integer.class);
        return count > 0;
    }
}
