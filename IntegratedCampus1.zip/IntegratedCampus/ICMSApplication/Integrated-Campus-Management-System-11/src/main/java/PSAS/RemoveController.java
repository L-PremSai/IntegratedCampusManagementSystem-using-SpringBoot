package PSAS;

import users.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class RemoveController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // Endpoint to fetch students based on courseId and yearOfJoining
    @GetMapping
    public List<Student> getStudents(@RequestParam String courseId, @RequestParam int yearOfJoining) {
        try {
            String sql = "SELECT * FROM students WHERE courseId = ? AND yearOfJoining = ?";
            return jdbcTemplate.query(sql, new Object[]{courseId, yearOfJoining}, new BeanPropertyRowMapper<>(Student.class));
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to fetch students: " + e.getMessage());
        }
    }

    // Endpoint to delete a student by hallTicketNumber
    @DeleteMapping("/{hallTicketNumber}")
    public void deleteStudent(@PathVariable String hallTicketNumber) {
        try {
            String sql = "DELETE FROM students WHERE hallTicketNumber = ?";
            jdbcTemplate.update(sql, hallTicketNumber);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to delete student: " + e.getMessage());
        }
    }
}
