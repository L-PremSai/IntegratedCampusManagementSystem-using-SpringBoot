package users;

public class StudentService {
	private String hallTicketNumber;
	private String fullName;
	private String phoneNumber;
	private String emailAddress;
	private String courseId;
	private String courseName;
	private int yearOfJoining;
	private String currentYear;
	
	public String gethallTicketNumber() {
		return hallTicketNumber;
	}
	public void sethallTicketNumber(String hallTicketNumber) {
		this.hallTicketNumber = hallTicketNumber;
	}
	public String getfullName() {
		return fullName;
	}
	public void setfullName(String fullName) {
		this.fullName = fullName;
	}
	public String getphoneNumber() {
		return phoneNumber;
	}
	public void setphoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getemailAddress() {
		return emailAddress;
	}
	public void setemailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getcourseId() {
		return courseId;
	}
	public void setcourseId(String courseId) {
		this.courseId = courseId;
	}
	public String getcourseName() {
		return courseName;
	}
	public void setcourseName(String courseName) {
		this.courseName = courseName;
	}
	public int getyearOfJoining() {
		return yearOfJoining;
	}
	public void setyearOfJoining(int yearOfJoining) {
		this.yearOfJoining = yearOfJoining;
	}
	public String getcurrentYear() {
		return currentYear;
	}
	public void setcurrentYear(String currentYear) {
		this.currentYear = currentYear;
	}
	@Override
	public String toString() {
		return "Student [hallTicket=" + hallTicketNumber + ", Name=" + fullName + "]";
	}
	
	
	
		

	

}
