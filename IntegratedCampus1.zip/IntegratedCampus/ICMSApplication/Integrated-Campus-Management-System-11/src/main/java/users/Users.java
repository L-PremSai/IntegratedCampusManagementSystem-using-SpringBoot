package users;

public class Users {
	private String email;
	private String password_ad;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword_ad() {
		return password_ad;
	}
	public void setPassword_ad(String password_ad) {
		this.password_ad = password_ad;
	}
	@Override
	public String toString() {
		return "Users [email=" + email + ", password_ad=" + password_ad + "]";
	}
	
	
	
		

	

}
