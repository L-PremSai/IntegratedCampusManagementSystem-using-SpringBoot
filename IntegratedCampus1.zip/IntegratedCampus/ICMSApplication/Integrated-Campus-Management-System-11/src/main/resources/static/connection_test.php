<!DOCTYPE html>
<html>
<head>
    <title>Student Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .delete-btn {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 6px 10px;
            cursor: pointer;
        }
        .edit-btn {
            background-color: #2196f3;
            color: white;
            border: none;
            padding: 6px 10px;
            cursor: pointer;
        }
        .search-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 6px 10px;
            cursor: pointer;
        }
        form {
            display: inline-block;
            margin-bottom: 10px;
        }
        form input[type="submit"] {
            vertical-align: middle;
        }
    </style>
</head>
<body>
   

    <form method="post">
        <label for="courseid">Select Course:</label>
        <select name="courseid" id="courseid">
            <option value="">-- Select Course --</option>
            <?php
            // Connect to Oracle
            $dbusername = "INTEGRATEDCAMPUS";
            $dbpassword = "12345";
            $dbhost = "localhost/XE"; // or your Oracle DB host and SID

            $conn = oci_connect($dbusername, $dbpassword, $dbhost);

            if (!$conn) {
                $e = oci_error();
                trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
            }

            // Fetch distinct course IDs from database
            $query_courseid = "SELECT DISTINCT COURSEID FROM STUDENTS";
            $stmt_courseid = oci_parse($conn, $query_courseid);
            oci_execute($stmt_courseid);
            while ($row_courseid = oci_fetch_array($stmt_courseid, OCI_ASSOC+OCI_RETURN_NULLS)) {
                $selected = (isset($_POST['courseid']) && $_POST['courseid'] == $row_courseid['COURSEID']) ? 'selected' : '';
                echo "<option value='" . $row_courseid['COURSEID'] . "' $selected>" . $row_courseid['COURSEID'] . "</option>";
            }

            // Add additional values manually
            $additional_courseids = array(77, 56);
            foreach ($additional_courseids as $courseid) {
                $selected = (isset($_POST['courseid']) && $_POST['courseid'] == $courseid) ? 'selected' : '';
                echo "<option value='$courseid' $selected>$courseid</option>";
            }

            // Display "CSM" with value 66 as number
            $selected = (isset($_POST['courseid']) && $_POST['courseid'] == '66') ? 'selected' : '';
            echo "<option value='66' $selected>CSM</option>";

            oci_free_statement($stmt_courseid);
            ?>
        </select>

        <label for="yearofjoining">Select Year:</label>
        <select name="yearofjoining" id="yearofjoining">
            <option value="">-- Select Year --</option>
            <?php
            // Fetch distinct years of joining from database
            $query_year = "SELECT DISTINCT YEAROFJOINING FROM STUDENTS";
            $stmt_year = oci_parse($conn, $query_year);
            oci_execute($stmt_year);
            while ($row_year = oci_fetch_array($stmt_year, OCI_ASSOC+OCI_RETURN_NULLS)) {
                $selected = (isset($_POST['yearofjoining']) && $_POST['yearofjoining'] == $row_year['YEAROFJOINING']) ? 'selected' : '';
                echo "<option value='" . $row_year['YEAROFJOINING'] . "' $selected>" . $row_year['YEAROFJOINING'] . "</option>";
            }

            // Add additional values manually
            $additional_years = array(2023, 2024);
            foreach ($additional_years as $year) {
                $selected = (isset($_POST['yearofjoining']) && $_POST['yearofjoining'] == $year) ? 'selected' : '';
                echo "<option value='$year' $selected>$year</option>";
            }

            oci_free_statement($stmt_year);
            ?>
        </select>

        <input type="submit" name="get" value="GET">
    </form>

    <form method="post">
        <label for="hallticketnumber">Search by Hall Ticket Number:</label>
        <input type="text" name="hallticketnumber" id="hallticketnumber">
        <input type="submit" name="searchByHallTicket" value="Search" class="search-btn">
    </form>

    <br>

    <table>
        <tr>
            <th>Hall Ticket Number</th>
            <th>Student Name</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Course ID</th>
            <th>Year of Joining</th>
            <th>Current Year</th>
            <th>Action</th>
        </tr>

        <?php
        // Handle search form submission
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Search by course ID and year of joining
            if (isset($_POST["get"])) {
                $courseid = $_POST["courseid"];
                $yearofjoining = $_POST["yearofjoining"];

                $query = "SELECT HALLTICKETNUMBER, FULLNAME, EMAILADDRESS, PHONENUMBER, COURSEID, YEAROFJOINING, CURRENTYEAR FROM STUDENTS";
                if (!empty($courseid)) {
                    $query .= " WHERE COURSEID = '$courseid'";
                    if (!empty($yearofjoining)) {
                        $query .= " AND YEAROFJOINING = '$yearofjoining'";
                    }
                } elseif (!empty($yearofjoining)) {
                    $query .= " WHERE YEAROFJOINING = '$yearofjoining'";
                }
            }
            // Search by hall ticket number (partial match)
            elseif (isset($_POST["searchByHallTicket"])) {
                $hallticketnumber = $_POST["hallticketnumber"];
                $query = "SELECT HALLTICKETNUMBER, FULLNAME, EMAILADDRESS, PHONENUMBER, COURSEID, YEAROFJOINING, CURRENTYEAR FROM STUDENTS WHERE HALLTICKETNUMBER LIKE '%$hallticketnumber%'";
            }

            $stmt = oci_parse($conn, $query);
            oci_execute($stmt);

            // Display student records in a table
            while ($row = oci_fetch_array($stmt, OCI_ASSOC+OCI_RETURN_NULLS)) {
                echo "<tr>";
                foreach ($row as $key => $value) {
                    echo "<td>" . htmlspecialchars($value, ENT_QUOTES) . "</td>";
                }
                // Add delete and edit buttons with confirmation for delete
                echo "<td>
                        <form method='post' action='delete.php' onsubmit='return confirmDelete();'>
                            <input type='hidden' name='hallticketnumber' value='" . $row['HALLTICKETNUMBER'] . "'>
                            <input type='submit' name='delete' class='delete-btn' value='Delete'>
                        </form>
                        <form action='edit.php' method='get'>
                            <input type='hidden' name='hallticketnumber' value='" . $row['HALLTICKETNUMBER'] . "'>
                            <input type='submit' class='edit-btn' value='Edit'>
                        </form>
                      </td>";
                echo "</tr>";
            }
            oci_free_statement($stmt);
        }

        // Close connection
        oci_close($conn);
        ?>
    </table>

    <script>
        function confirmDelete() {
            return confirm("Are you sure you want to delete this student?");
        }
    </script>

</body>
</html>
