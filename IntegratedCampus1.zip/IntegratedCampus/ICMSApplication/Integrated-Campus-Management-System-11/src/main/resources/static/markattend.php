<?php
$servername = "localhost";
$username = "INTEGRATEDCAMPUS";
$password = "12345";
$dbname = "XE";

// Create connection
$conn = oci_connect($username, $password, $servername . '/' . $dbname);

// Check connection
if (!$conn) {
    $e = oci_error();
    die("Connection failed: " . $e['message']);
}

// Add a new book
if (isset($_POST['add'])) {
    $bookid = $_POST['bookid'];
    $bookname = $_POST['bookname'];
    $author = $_POST['author'];
    $image_path = $_POST['image_path'];

    $sql = "INSERT INTO books (bookid, bookname, author, image_path) VALUES (:bookid, :bookname, :author, :image_path)";
    $stid = oci_parse($conn, $sql);
    oci_bind_by_name($stid, ':bookid', $bookid);
    oci_bind_by_name($stid, ':bookname', $bookname);
    oci_bind_by_name($stid, ':author', $author);
    oci_bind_by_name($stid, ':image_path', $image_path);
    if (oci_execute($stid)) {
        echo "New book added successfully";
    } else {
        $e = oci_error($stid);
        echo "Error: " . $e['message'];
    }
}

// Delete a book
if (isset($_POST['delete'])) {
    $bookid = $_POST['bookid'];

    $sql = "DELETE FROM books WHERE bookid = :bookid";
    $stid = oci_parse($conn, $sql);
    oci_bind_by_name($stid, ':bookid', $bookid);
    if (oci_execute($stid)) {
        echo "Book deleted successfully";
    } else {
        $e = oci_error($stid);
        echo "Error: " . $e['message'];
    }
}

// Edit a book
if (isset($_POST['edit'])) {
    $bookid = $_POST['bookid'];
    $bookname = $_POST['bookname'];
    $author = $_POST['author'];
    $image_path = $_POST['image_path'];

    $sql = "UPDATE books SET bookname = :bookname, author = :author, image_path = :image_path WHERE bookid = :bookid";
    $stid = oci_parse($conn, $sql);
    oci_bind_by_name($stid, ':bookid', $bookid);
    oci_bind_by_name($stid, ':bookname', $bookname);
    oci_bind_by_name($stid, ':author', $author);
    oci_bind_by_name($stid, ':image_path', $image_path);
    if (oci_execute($stid)) {
        echo "Book updated successfully";
    } else {
        $e = oci_error($stid);
        echo "Error: " . $e['message'];
    }
}

// Retrieve data
$sql = "SELECT * FROM books";
$stid = oci_parse($conn, $sql);
oci_execute($stid);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Book Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        header {
            background: #333;
            color: #fff;
            padding-top: 30px;
            min-height: 70px;
            border-bottom: #777 3px solid;
        }
        header a {
            color: #fff;
            text-decoration: none;
            text-transform: uppercase;
            font-size: 16px;
        }
        header ul {
            padding: 0;
            list-style: none;
        }
        header li {
            display: inline;
            padding: 0 20px 0 20px;
        }
        .form-container {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        .form-container label {
            display: block;
            margin: 10px 0 5px;
        }
        .form-container input[type="text"], 
        .form-container input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-container button {
            padding: 10px 20px;
            background: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-container button:hover {
            background: #555;
        }
        .book-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 20px;
        }
        .book-card {
            background: #fff;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 16px;
            width: 200px;
            text-align: center;
        }
        .book-card img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }
        .book-card h4 {
            margin: 10px 0;
            font-size: 18px;
            color: #333;
        }
        .book-card p {
            color: #777;
            margin: 5px 0;
        }
        .book-card button {
            padding: 5px 10px;
            background: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 5px;
        }
        .book-card button:hover {
            background: #555;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>Book Management</h1>
        </div>
    </header>
    <div class="container">
        <div class="form-container">
            <form method="post" action="">
                <label>Book ID:</label>
                <input type="number" name="bookid" value="<?php echo isset($book['BOOKID']) ? $book['BOOKID'] : ''; ?>" required><br>
                <label>Book Name:</label>
                <input type="text" name="bookname" value="<?php echo isset($book['BOOKNAME']) ? $book['BOOKNAME'] : ''; ?>" required><br>
                <label>Author:</label>
                <input type="text" name="author" value="<?php echo isset($book['AUTHOR']) ? $book['AUTHOR'] : ''; ?>" required><br>
                <label>Image Path:</label>
                <input type="text" name="image_path" value="<?php echo isset($book['IMAGE_PATH']) ? $book['IMAGE_PATH'] : ''; ?>"><br>
                <button type="submit" name="add">Add Book</button>
                <button type="submit" name="edit">Edit Book</button>
            </form>
        </div>

        <h3>Book List</h3>
        <div class="book-container">
            <?php
            while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
                echo "<div class='book-card'>";
                echo "<img src='" . $row['IMAGE_PATH'] . "' alt='" . $row['BOOKNAME'] . "'>";
                echo "<h4>" . $row['BOOKNAME'] . "</h4>";
                echo "<p>" . $row['AUTHOR'] . "</p>";
                echo "<form method='post' action='' style='display:inline;'>
                        <input type='hidden' name='bookid' value='" . $row['BOOKID'] . "'>
                        <button type='submit' name='delete'>Delete</button>
                      </form>
                      <form method='post' action='' style='display:inline;'>
                        <input type='hidden' name='bookid' value='" . $row['BOOKID'] . "'>
                        <button type='submit' name='edit'>Edit</button>
                      </form>";
                echo "</div>";
            }
            ?>
        </div>
    </div>
</body>
</html>

<?php
oci_free_statement($stid);
oci_close($conn);
?>
