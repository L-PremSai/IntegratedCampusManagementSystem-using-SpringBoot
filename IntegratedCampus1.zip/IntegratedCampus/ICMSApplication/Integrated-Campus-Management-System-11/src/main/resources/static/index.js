




function toggleMenu() {
    var checkbox = document.getElementById('burger-toggle');
    checkbox.checked = !checkbox.checked;
}


let slideIndex = 0;




function showSlides() {
    // Initialize slides
    let slides = document.getElementsByClassName("slide");

    // Ensure slides exist
    if (!slides || slides.length === 0) {
        console.error("No slides found with the class 'slide'");
        return;
    }

    // Hide all slides
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }

    // Reset slideIndex if it exceeds the length
    if (slideIndex >= slides.length) {
        slideIndex = 0;
    }

    // Display the current slide
    slides[slideIndex].style.display = "block";

    // Increment slideIndex for the next slide
    slideIndex++;

    // Schedule the next slide to be shown after 3 seconds
    setTimeout(showSlides, 3000);
}
document.addEventListener("DOMContentLoaded", function() {
    // Your JavaScript code here, including the showSlides function
    showSlides();
});

function signup_page(){
   window.location.href="signup.html";
   }
   
function login_page(){
  window.location.href="login.html";
  }


  
  




