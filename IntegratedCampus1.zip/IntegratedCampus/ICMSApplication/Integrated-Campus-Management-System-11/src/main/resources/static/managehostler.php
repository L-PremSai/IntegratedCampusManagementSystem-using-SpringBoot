<?php
// Database connection details
$servername = "localhost";
$username = "INTEGRATEDCAMPUS";
$password = "12345";
$dbname = "XE";

// Create connection
$conn = oci_connect($username, $password, $servername . '/' . $dbname);

// Check connection
if (!$conn) {
    $e = oci_error();
    die("Connection failed: " . htmlspecialchars($e['message']));
}

// Handle form submission for adding single hostel allocation or uploading Excel file
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if adding single hostel allocation form is submitted
    if (isset($_POST['submit'])) {
        // Validate and sanitize inputs
        $hallticketnumber = isset($_POST['hallticketnumber']) ? htmlspecialchars($_POST['hallticketnumber']) : '';
        $hostelname = isset($_POST['hostelname']) ? htmlspecialchars($_POST['hostelname']) : '';
        $joiningdate = isset($_POST['joiningdate']) ? htmlspecialchars($_POST['joiningdate']) : '';

        // Check if all required fields are provided
        if (!empty($hallticketnumber) && !empty($hostelname) && !empty($joiningdate)) {
            // Check if hall ticket number exists in students table
            $query = "SELECT COUNT(*) AS count FROM students WHERE hallticketnumber = :hallticketnumber";
            $stmt = oci_parse($conn, $query);
            oci_bind_by_name($stmt, ':hallticketnumber', $hallticketnumber);
            oci_execute($stmt);
            $row = oci_fetch_assoc($stmt);
            $count = $row['COUNT'];
            oci_free_statement($stmt);

            if ($count > 0) {
                // Hall ticket number exists, proceed with insertion
                $sql = "INSERT INTO hostelers (hallticketnumber, hostelname, joiningdate) 
                        VALUES (:hallticketnumber, :hostelname, TO_DATE(:joiningdate, 'YYYY-MM-DD'))";
                $stmt = oci_parse($conn, $sql);
                oci_bind_by_name($stmt, ':hallticketnumber', $hallticketnumber);
                oci_bind_by_name($stmt, ':hostelname', $hostelname);
                oci_bind_by_name($stmt, ':joiningdate', $joiningdate);
                
                $result = oci_execute($stmt);
                if (!$result) {
                    $e = oci_error($stmt);
                    die("Error: " . htmlspecialchars($e['message']));
                }
                oci_free_statement($stmt);
                echo "Hostel allocation added successfully.";
            } else {
                // Hall ticket number does not exist in students table
                echo "Error: Hall ticket number does not exist in the students table.";
            }
        } else {
            echo "Error: Please fill in all fields.";
        }
    }


    
}

// Close connection
oci_close($conn);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Hostel Allocation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
        }
        .container h3 {
            font-size: 18px;
            margin-bottom: 10px;
            color: #333;
        }
        .container p {
            color: #777;
            margin: 5px 0;
        }
        .container form {
            margin-top: 10px;
        }
        .container form input[type="text"], .container form input[type="date"], .container form input[type="file"] {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: calc(100% - 16px);
            margin-bottom: 10px;
        }
        .container form input[type="submit"] {
            padding: 8px 16px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px;
        }
        .container form input[type="submit"]:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <div class="container">
        <h3>Add Hostel Allocation</h3>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="text" name="hallticketnumber" placeholder="Enter Hall Ticket Number" required>
            <input type="text" name="hostelname" placeholder="Enter Hostel Name" required>
            <input type="date" name="joiningdate" required>
            <input type="submit" name="submit" value="Add Hostel Allocation">
        </form>
        
        <hr>
        
    </div>
</body>
</html>
