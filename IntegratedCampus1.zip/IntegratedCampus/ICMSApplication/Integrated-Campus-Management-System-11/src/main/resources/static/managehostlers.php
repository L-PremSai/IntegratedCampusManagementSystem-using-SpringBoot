<!DOCTYPE html>
<html>
<head>
    <title>Hostel Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .delete-btn {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 6px 10px;
            cursor: pointer;
        }
        .edit-btn {
            background-color: #2196f3;
            color: white;
            border: none;
            padding: 6px 10px;
            cursor: pointer;
        }
        .search-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 6px 10px;
            cursor: pointer;
        }
        form {
            display: inline-block;
            margin-bottom: 10px;
        }
        form input[type="submit"] {
            vertical-align: middle;
        }
    </style>
</head>
<body>
    <h2>Hostel Management System</h2>

    <form method="post">
        <label for="hostelname">Select Hostel</label>
        <select name="hostelname" id="hostelname">
            <option value="">-- Select Hostel --</option>
            <option value="All">All</option>
            <option value="Power Gym">Power Gym</option>
            <option value="Balaji">Balaji</option>
            <?php
            // Connect to Oracle
            $dbusername = "INTEGRATEDCAMPUS";
            $dbpassword = "12345";
            $dbhost = "localhost/XE"; // or your Oracle DB host and SID

            $conn = oci_connect($dbusername, $dbpassword, $dbhost);

            if (!$conn) {
                $e = oci_error();
                trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
            }

            // Fetch distinct hostel names from database
            $query_hostelname = "SELECT DISTINCT HOSTELNAME FROM HOSTELERS";
            $stmt_hostelname = oci_parse($conn, $query_hostelname);
            oci_execute($stmt_hostelname);
            while ($row_hostelname = oci_fetch_array($stmt_hostelname, OCI_ASSOC+OCI_RETURN_NULLS)) {
                $selected = (isset($_POST['hostelname']) && $_POST['hostelname'] == $row_hostelname['HOSTELNAME']) ? 'selected' : '';
                echo "<option value='" . $row_hostelname['HOSTELNAME'] . "' $selected>" . $row_hostelname['HOSTELNAME'] . "</option>";
            }

            oci_free_statement($stmt_hostelname);
            ?>
        </select>

        <input type="submit" name="get" value="GET">
    </form>

    <form method="post">
        <label for="hallticketnumber">Search by Hall Ticket Number:</label>
        <input type="text" name="hallticketnumber" id="hallticketnumber">
        <input type="submit" name="searchByHallTicket" value="Search" class="search-btn">
    </form>

    <br>

    <table>
        <tr>
            <th>Hall Ticket Number</th>
            <th>Student Name</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Hostel Name</th>
            <th>Action</th>
        </tr>

        <?php
        // Handle search form submission
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Search by hostel name
            if (isset($_POST["get"])) {
                $hostelname = $_POST["hostelname"];

                if ($hostelname == "All") {
                    $query = "SELECT s.HALLTICKETNUMBER, s.FULLNAME, s.EMAILADDRESS, s.PHONENUMBER, h.HOSTELNAME
                              FROM STUDENTS s
                              INNER JOIN HOSTELERS h ON s.HALLTICKETNUMBER = h.HALLTICKETNUMBER";
                } else {
                    $query = "SELECT s.HALLTICKETNUMBER, s.FULLNAME, s.EMAILADDRESS, s.PHONENUMBER, h.HOSTELNAME
                              FROM STUDENTS s
                              INNER JOIN HOSTELERS h ON s.HALLTICKETNUMBER = h.HALLTICKETNUMBER
                              WHERE h.HOSTELNAME = :hostelname";
                }
                
                $stmt = oci_parse($conn, $query);
                if ($hostelname != "All") {
                    oci_bind_by_name($stmt, ':hostelname', $hostelname);
                }
                oci_execute($stmt);
            }
            // Search by hall ticket number (partial match)
            elseif (isset($_POST["searchByHallTicket"])) {
                $hallticketnumber = $_POST["hallticketnumber"];
                $query = "SELECT s.HALLTICKETNUMBER, s.FULLNAME, s.EMAILADDRESS, s.PHONENUMBER, h.HOSTELNAME
                          FROM STUDENTS s
                          INNER JOIN HOSTELERS h ON s.HALLTICKETNUMBER = h.HALLTICKETNUMBER
                          WHERE s.HALLTICKETNUMBER LIKE '%' || :hallticketnumber || '%'";
                $stmt = oci_parse($conn, $query);
                oci_bind_by_name($stmt, ':hallticketnumber', $hallticketnumber);
                oci_execute($stmt);
            }

            // Display student records in a table
            while ($row = oci_fetch_array($stmt, OCI_ASSOC+OCI_RETURN_NULLS)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['HALLTICKETNUMBER'], ENT_QUOTES) . "</td>";
                echo "<td>" . htmlspecialchars($row['FULLNAME'], ENT_QUOTES) . "</td>";
                echo "<td>" . htmlspecialchars($row['EMAILADDRESS'], ENT_QUOTES) . "</td>";
                echo "<td>" . htmlspecialchars($row['PHONENUMBER'], ENT_QUOTES) . "</td>";
                echo "<td>" . htmlspecialchars($row['HOSTELNAME'], ENT_QUOTES) . "</td>";
                // Add delete and edit buttons with confirmation for delete
                echo "<td>
                        <form method='post' action='delete1.php' onsubmit='return confirmDelete();'>
                            <input type='hidden' name='hallticketnumber' value='" . $row['HALLTICKETNUMBER'] . "'>
                            <input type='submit' name='delete' class='delete-btn' value='Delete'>
                        </form>
                        
                      </td>";
                echo "</tr>";
            }
            oci_free_statement($stmt);
        }

        // Close connection
        oci_close($conn);
        ?>
    </table>

    <script>
        function confirmDelete() {
            return confirm("Are you sure you want to delete this student?");
        }
    </script>

</body>
</html>
