<?php
// Database connection details
$servername = "localhost";
$username = "INTEGRATEDCAMPUS";
$password = "12345";
$dbname = "XE";

// Create connection
$conn = oci_connect($username, $password, $servername . '/' . $dbname);

// Check connection
if (!$conn) {
    $e = oci_error();
    die("Connection failed: " . htmlspecialchars($e['message']));
}

// Initialize variables for form handling
$bookid = '';
$hallticketnumber = '';
$allot_date = date('Y-m-d'); // Current date
$error_message = '';

// Handle form submission for book allotment
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize inputs
    $hallticketnumber = htmlspecialchars($_POST['hallticketnumber']);
    $bookid = htmlspecialchars($_POST['bookid']);

    // Check if hall ticket number is valid (exists in students table)
    $validate_sql = "SELECT COUNT(*) AS count FROM students WHERE hallticketnumber = :hallticketnumber";
    $validate_stmt = oci_parse($conn, $validate_sql);
    oci_bind_by_name($validate_stmt, ':hallticketnumber', $hallticketnumber);
    oci_execute($validate_stmt);
    $row = oci_fetch_array($validate_stmt, OCI_ASSOC);
    $count = $row['COUNT'];

    if ($count == 0) {
        $error_message = "Invalid Hall Ticket Number. Please enter a valid Hall Ticket Number.";
    } else {
        // Insert into database table allotedbooks
        $insert_sql = "INSERT INTO allotedbooks (bookid, hallticketnumber, allot_date) 
                       VALUES (:bookid, :hallticketnumber, TO_DATE(:allot_date, 'YYYY-MM-DD'))";
        $stmt = oci_parse($conn, $insert_sql);
        oci_bind_by_name($stmt, ':bookid', $bookid);
        oci_bind_by_name($stmt, ':hallticketnumber', $hallticketnumber);
        oci_bind_by_name($stmt, ':allot_date', $allot_date);

        $result = oci_execute($stmt);
        if (!$result) {
            $e = oci_error($stmt);
            die("Error: " . htmlspecialchars($e['message']));
        }

        // Close statement
        oci_free_statement($stmt);

        // Clear form variables after successful allotment
        $bookid = '';
        $hallticketnumber = '';
    }
}

// SQL query to retrieve books data
$sql = "SELECT * FROM books";
$stid = oci_parse($conn, $sql);
oci_execute($stid);

// Array to hold retrieved books data
$books = array();

// Fetch and store each row of books data
while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
    $books[] = $row;
}

// Close statement and connection
oci_free_statement($stid);
oci_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Books</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        .book-card {
            background: #fff;
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .book-card img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 10px;
        }
        .book-card h3 {
            font-size: 18px;
            margin-bottom: 10px;
            color: #333;
        }
        .book-card p {
            color: #777;
            margin: 5px 0;
        }
        .book-card form {
            margin-top: 10px;
        }
        .book-card form input[type="text"] {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .book-card form input[type="submit"] {
            padding: 8px 16px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px;
        }
        .book-card form input[type="submit"]:hover {
            background-color: #555;
        }
        .error-message {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php foreach ($books as $book): ?>
            <div class="book-card">
                <img src="<?php echo htmlspecialchars($book['IMAGE_PATH']); ?>" alt="<?php echo htmlspecialchars($book['BOOKNAME']); ?>">
                <h3><?php echo htmlspecialchars($book['BOOKNAME']); ?></h3>
                <p>Author: <?php echo htmlspecialchars($book['AUTHOR']); ?></p>
                <p>Book ID: <?php echo htmlspecialchars($book['BOOKID']); ?></p>
                <!-- Allotment form -->
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <input type="hidden" name="bookid" value="<?php echo htmlspecialchars($book['BOOKID']); ?>">
                    <input type="text" name="hallticketnumber" placeholder="Enter Hall Ticket Number" required>
                    <input type="submit" value="Allot">
                </form>
            </div>
        <?php endforeach; ?>

        <!-- Display error message if invalid hall ticket number -->
        <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
