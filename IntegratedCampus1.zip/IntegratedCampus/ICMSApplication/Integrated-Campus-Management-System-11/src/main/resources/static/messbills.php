<!DOCTYPE html>
<html>
<head>
    <title>Upload and Process Monthly Excel File</title>
</head>
<body>
    <h2>Upload and Process Monthly Excel File</h2>

    <?php
    // Specify the path to PHPExcel library
    require_once 'C:\xampp\htdocs\PHPExcel-master\PHPExcel-master\PHPExcel\IOFactory.php';

    // Database configuration
    $dbusername = "INTEGRATEDCAMPUS";
    $dbpassword = "12345";
    $dbhost = "localhost/XE"; // Change this to your Oracle DB host and SID

    // Handle file upload and processing
    if(isset($_POST["submit"])) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["excel_file"]["name"]);
        $uploadOk = 1;
        $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if file already exists
        if (file_exists($target_file)) {
            echo "Sorry, file already exists.";
            $uploadOk = 0;
        }

        // Check file size
        if ($_FILES["excel_file"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        // Allow certain file formats
        if($fileType != "xls" && $fileType != "xlsx") {
            echo "Sorry, only XLS, XLSX files are allowed.";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        } else {
            if (move_uploaded_file($_FILES["excel_file"]["tmp_name"], $target_file)) {
                echo "The file ". htmlspecialchars( basename( $_FILES["excel_file"]["name"])). " has been uploaded.";

                // Process the Excel file and store data in the database
                try {
                    // Connect to Oracle database
                    $conn = oci_connect($dbusername, $dbpassword, $dbhost);
                    if (!$conn) {
                        $e = oci_error();
                        trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
                    }

                    // Read data from Excel file
                    $objPHPExcel = PHPExcel_IOFactory::load($target_file);
                    $worksheet = $objPHPExcel->getActiveSheet();
                    $highestRow = $worksheet->getHighestDataRow();

                    // Prepare SQL statement to insert data into database
                    $insertQuery = "INSERT INTO MONTHLY_BILLS (hallticketnumber, Month, fees) VALUES (:hallticketnumber, :Month, :fees)";
                    $stmt = oci_parse($conn, $insertQuery);

                    // Iterate through rows and insert data
                    for ($row = 2; $row <= $highestRow; $row++) { // Assuming first row is headers
                        $hallticketnumber = $worksheet->getCellByColumnAndRow(0, $row)->getValue(); // Adjust column index as per your Excel structure
                        $Month = $worksheet->getCellByColumnAndRow(1, $row)->getValue(); // Adjust column index as per your Excel structure
                        $fees = $worksheet->getCellByColumnAndRow(2, $row)->getValue(); // Adjust column index as per your Excel structure

                        // Bind parameters and execute SQL statement
                        oci_bind_by_name($stmt, ':hallticketnumber', $hallticketnumber);
                        oci_bind_by_name($stmt, ':Month', $Month);
                        oci_bind_by_name($stmt, ':fees', $fees);
                        oci_execute($stmt);
                    }

                    // Close statement and database connection
                    oci_free_statement($stmt);
                    oci_close($conn);

                    echo "<br>Data successfully inserted into database.";

                } catch (Exception $e) {
                    echo "Error processing file: " . $e->getMessage();
                }
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    }
    ?>

    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
        <input type="file" name="excel_file" accept=".xls,.xlsx">
        <input type="submit" value="Upload File" name="submit">
    </form>

</body>
</html>
