<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        form {
            width: 300px;
            margin: 0 auto;
        }
        label {
            display: block;
            margin-top: 10px;
        }
        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h2>Edit Student</h2>

    <?php
    // Connect to Oracle
    $dbusername = "INTEGRATEDCAMPUS";
    $dbpassword = "12345";
    $dbhost = "localhost/XE"; // or your Oracle DB host and SID

    $conn = oci_connect($dbusername, $dbpassword, $dbhost);

    if (!$conn) {
        $e = oci_error();
        trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
    }

    if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['hallticketnumber'])) {
        $hallticketnumber = $_GET['hallticketnumber'];

        // Fetch student details including course name
        $query = "SELECT HALLTICKETNUMBER, FULLNAME, EMAILADDRESS, PHONENUMBER, COURSEID, COURSENAME, YEAROFJOINING, CURRENTYEAR FROM STUDENTS WHERE HALLTICKETNUMBER = :hallticketnumber";
        $stmt = oci_parse($conn, $query);
        oci_bind_by_name($stmt, ':hallticketnumber', $hallticketnumber);
        oci_execute($stmt);

        $student = oci_fetch_assoc($stmt);

        if ($student) {
            ?>
            <form method="post" action="edit.php">
                <input type="hidden" name="hallticketnumber" value="<?php echo htmlspecialchars($student['HALLTICKETNUMBER'], ENT_QUOTES); ?>">
                <label for="fullname">Full Name:</label>
                <input type="text" name="fullname" id="fullname" value="<?php echo htmlspecialchars($student['FULLNAME'], ENT_QUOTES); ?>">
                <label for="email">Email:</label>
                <input type="text" name="email" id="email" value="<?php echo htmlspecialchars($student['EMAILADDRESS'], ENT_QUOTES); ?>">
                <label for="phonenumber">Phone Number:</label>
                <input type="text" name="phonenumber" id="phonenumber" value="<?php echo htmlspecialchars($student['PHONENUMBER'], ENT_QUOTES); ?>">
                <label for="courseid">Course ID:</label>
                <input type="text" name="courseid" id="courseid" value="<?php echo htmlspecialchars($student['COURSEID'], ENT_QUOTES); ?>">
                <label for="coursename">Course Name:</label>
                <input type="text" name="coursename" id="coursename" value="<?php echo htmlspecialchars($student['COURSENAME'], ENT_QUOTES); ?>">
                <label for="yearofjoining">Year of Joining:</label>
                <input type="text" name="yearofjoining" id="yearofjoining" value="<?php echo htmlspecialchars($student['YEAROFJOINING'], ENT_QUOTES); ?>">
                <label for="currentyear">Current Year:</label>
                <input type="text" name="currentyear" id="currentyear" value="<?php echo htmlspecialchars($student['CURRENTYEAR'], ENT_QUOTES); ?>">
                <input type="submit" name="update" value="Update">
            </form>
            <?php
        } else {
            echo "Student record not found.";
        }

        oci_free_statement($stmt);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
        $hallticketnumber = $_POST['hallticketnumber'];
        $fullname = $_POST['fullname'];
        $email = $_POST['email'];
        $phonenumber = $_POST['phonenumber'];
        $courseid = $_POST['courseid'];
        $coursename = $_POST['coursename'];
        $yearofjoining = $_POST['yearofjoining'];
        $currentyear = $_POST['currentyear'];

        // Update student details including course name
        $query = "UPDATE STUDENTS SET FULLNAME = :fullname, EMAILADDRESS = :email, PHONENUMBER = :phonenumber, COURSEID = :courseid, COURSENAME = :coursename, YEAROFJOINING = :yearofjoining, CURRENTYEAR = :currentyear WHERE HALLTICKETNUMBER = :hallticketnumber";
        $stmt = oci_parse($conn, $query);
        oci_bind_by_name($stmt, ':hallticketnumber', $hallticketnumber);
        oci_bind_by_name($stmt, ':fullname', $fullname);
        oci_bind_by_name($stmt, ':email', $email);
        oci_bind_by_name($stmt, ':phonenumber', $phonenumber);
        oci_bind_by_name($stmt, ':courseid', $courseid);
        oci_bind_by_name($stmt, ':coursename', $coursename);
        oci_bind_by_name($stmt, ':yearofjoining', $yearofjoining);
        oci_bind_by_name($stmt, ':currentyear', $currentyear);

        $result = oci_execute($stmt);
        if ($result) {
            echo "Student record updated successfully.";
        } else {
            $e = oci_error($stmt);
            echo "Error updating record: " . htmlentities($e['message'], ENT_QUOTES);
        }

        oci_free_statement($stmt);
        oci_close($conn);

        // Redirect back to the main page
        header("Location: connection_test.php");
        exit();
    }

    // Close connection
    oci_close($conn);
    ?>
</body>
</html>
