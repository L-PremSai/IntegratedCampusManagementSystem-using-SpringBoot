<?php
// Database connection
$db_user = "INTEGRATEDCAMPUS";
$db_pass = "12345";
$db_sid = "localhost/XE";

$conn = oci_connect($db_user, $db_pass, $db_sid);

if (!$conn) {
    $e = oci_error();
    die("Connection failed: " . $e['message']);
}

// Initialize variables for date range query
$start_date = isset($_POST['start_date']) ? $_POST['start_date'] : date('Y-m-d', strtotime('-1 week'));
$end_date = isset($_POST['end_date']) ? $_POST['end_date'] : date('Y-m-d');

// Fetch attendance data based on date range
$sql = "SELECT sa.hallticketnumber, s.fullname, sa.attendance_date, sa.hours
        FROM studentattendance sa
        INNER JOIN students s ON sa.hallticketnumber = s.hallticketnumber
        WHERE sa.attendance_date BETWEEN TO_DATE(:start_date, 'YYYY-MM-DD') AND TO_DATE(:end_date, 'YYYY-MM-DD')";

$stid = oci_parse($conn, $sql);
oci_bind_by_name($stid, ':start_date', $start_date);
oci_bind_by_name($stid, ':end_date', $end_date);
oci_execute($stid);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Attendance Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #00246B; /* Background color of headers */
            color: white; /* Text color of headers */
        }
        tr {
            background-color: #CADCFC; /* Row background color */
        }
        .floating-button {
            background-color: #00246B; /* Button background color */
            color: white; /* Button text color */
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 5px; /* Rounded corners */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }
        .floating-button:hover {
            background-color: #0056b3; /* Darker shade on hover */
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }
        .search-form {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <form method="post" class="search-form">
        <label for="start_date">Start Date:</label>
        <input type="date" id="start_date" name="start_date" value="<?php echo $start_date; ?>">
        
        <label for="end_date">End Date:</label>
        <input type="date" id="end_date" name="end_date" value="<?php echo $end_date; ?>">
        
        <button type="submit" class="floating-button">Search</button>
    </form>
    
    <table>
        <thead>
            <tr>
                <th>Hall Ticket Number</th>
                <th>Full Name</th>
                <th>Attendance Date</th>
                <th>Hours</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
                echo "<tr>";
                echo "<td>" . $row["HALLTICKETNUMBER"] . "</td>";
                echo "<td>" . $row["FULLNAME"] . "</td>";
                echo "<td>" . $row["ATTENDANCE_DATE"] . "</td>";
                echo "<td>" . $row["HOURS"] . "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>

<?php
oci_free_statement($stid);
oci_close($conn);
?>
