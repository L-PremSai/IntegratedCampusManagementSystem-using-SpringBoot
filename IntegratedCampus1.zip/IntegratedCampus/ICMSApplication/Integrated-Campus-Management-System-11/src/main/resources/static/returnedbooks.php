<!DOCTYPE html>
<html>
<head>
    <title>Returned Books</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2>Returned Books</h2>

<table>
    <tr>
        <th>Book ID</th>
        <th>Hall Ticket Number</th>
        <th>Full Name</th>
        <th>Course ID</th>
        <th>Allotment Date</th>
        <th>Return Date</th>
    </tr>

<?php
// Database connection
$conn = oci_connect("INTEGRATEDCAMPUS", "12345", "localhost/XE");

if (!$conn) {
    $e = oci_error();
    die("Connection failed: " . $e['message']);
}

// Query to retrieve returned books with fullname and COURSENAME from students table
$sql = "SELECT ab.BOOKID, ab.HALLTICKETNUMBER, s.fullname AS FULLNAME, s.coursename AS COURSENAME, ab.ALLOT_DATE, ab.RETURN_DATE
        FROM allotedbooks ab
        JOIN students s ON ab.HALLTICKETNUMBER = s.hallticketnumber
        WHERE ab.RETURN_DATE IS NOT NULL"; // Only select books that have been returned

$stmt = oci_parse($conn, $sql);

if (!$stmt) {
    $e = oci_error($conn);
    die("Query preparation failed: " . $e['message']);
}

// Execute the statement
if (oci_execute($stmt)) {
    while ($row = oci_fetch_assoc($stmt)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['BOOKID'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['HALLTICKETNUMBER'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['FULLNAME'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['COURSENAME'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['ALLOT_DATE'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['RETURN_DATE'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "</tr>";
    }
} else {
    $e = oci_error($stmt);
    die("Query execution failed: " . $e['message']);
}

oci_free_statement($stmt);
oci_close($conn);
?>
</table>

</body>
</html>
