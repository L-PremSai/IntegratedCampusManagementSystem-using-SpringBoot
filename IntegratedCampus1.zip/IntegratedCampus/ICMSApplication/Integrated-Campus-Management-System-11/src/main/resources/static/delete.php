<?php
// Connect to Oracle
$dbusername = "INTEGRATEDCAMPUS";
$dbpassword = "12345";
$dbhost = "localhost/XE"; // or your Oracle DB host and SID

$conn = oci_connect($dbusername, $dbpassword, $dbhost);

if (!$conn) {
    $e = oci_error();
    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    $hallticketnumber = $_POST['hallticketnumber'];

    // Delete student record
    $query = "DELETE FROM STUDENTS WHERE HALLTICKETNUMBER = :hallticketnumber";
    $stmt = oci_parse($conn, $query);
    oci_bind_by_name($stmt, ':hallticketnumber', $hallticketnumber);

    $result = oci_execute($stmt);
    if ($result) {
        echo "Student record deleted successfully.";
    } else {
        $e = oci_error($stmt);
        echo "Error deleting record: " . htmlentities($e['message'], ENT_QUOTES);
    }

    oci_free_statement($stmt);
    oci_close($conn);

    // Redirect back to the main page
    header("Location: connection_test.php");
    exit();
}
?>
