<!DOCTYPE html>
<html>
<head>
    <title>Paid Mess Bills</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2>View Paid Mess Bills</h2>

<form method="post" action="">
    <label for="month">Select Month:</label>
    <select id="month" name="month">
        <option value="January">January</option>
        <option value="February">February</option>
        <option value="March">March</option>
        <option value="April">April</option>
        <option value="May">May</option>
        <option value="June">June</option>
        <option value="July">July</option>
        <option value="August">August</option>
        <option value="September">September</option>
        <option value="October">October</option>
        <option value="November">November</option>
        <option value="December">December</option>
    </select>
    <button type="submit" name="submit">Get Paid Bills</button>
</form>

<?php
if (isset($_POST['submit'])) {
    $selectedMonth = $_POST['month'];

    // Database connection
    $conn = oci_connect("INTEGRATEDCAMPUS", "12345", "localhost/XE");

    if (!$conn) {
        $e = oci_error();
        die("Connection failed: " . $e['message']);
    }

    $sql = "SELECT s.hallticketnumber, s.fullname, p.fees, p.date_paid
            FROM students s
            JOIN paid_bills p ON s.hallticketnumber = p.hallticketnumber
            WHERE p.month = :month";
    
    $stmt = oci_parse($conn, $sql);
    oci_bind_by_name($stmt, ":month", $selectedMonth);
    oci_execute($stmt);

    echo "<h3>Paid Mess Bills for $selectedMonth</h3>";
    echo "<table>";
    echo "<tr><th>Hall Ticket Number</th><th>Student Full Name</th><th>Mess Bill</th><th>Date Paid</th></tr>";

    while ($row = oci_fetch_assoc($stmt)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['HALLTICKETNUMBER'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['FULLNAME'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['FEES'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['DATE_PAID'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "</tr>";
    }

    echo "</table>";

    oci_free_statement($stmt);
    oci_close($conn);
}
?>

</body>
</html>
