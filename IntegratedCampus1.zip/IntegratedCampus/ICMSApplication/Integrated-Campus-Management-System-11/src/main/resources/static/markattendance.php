<?php
// Database connection
$db_user = "INTEGRATEDCAMPUS";
$db_pass = "12345";
$db_sid = "localhost/XE";

$conn = oci_connect($db_user, $db_pass, $db_sid);

if (!$conn) {
    $e = oci_error();
    die("Connection failed: " . $e['message']);
}

// Fetch student details based on search and filters
$sql = "SELECT hallticketnumber, fullname FROM students";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search'])) {
    $searchTerm = $_POST['searchTerm'];
    $selectedCourse = $_POST['coursename'];
    $selectedYear = $_POST['currentyear'];
    
    $conditions = [];
    if (!empty($searchTerm)) {
        $conditions[] = "(hallticketnumber LIKE '%$searchTerm%' OR fullname LIKE '%$searchTerm%')";
    }
    if (!empty($selectedCourse)) {
        $conditions[] = "coursename = '$selectedCourse'";
    }
    if (!empty($selectedYear)) {
        $conditions[] = "currentyear = '$selectedYear'";
    }
    if (!empty($conditions)) {
        $sql .= " WHERE " . implode(" AND ", $conditions);
    }
}
$stid = oci_parse($conn, $sql);
oci_execute($stid);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $date = date("d-M-y");
    $hours = $_POST['hours'];
    $coursename = $_POST['coursename'];
    $currentyear = $_POST['currentyear'];

    $successMessage = "";

    // Merge statement to insert or update totalhours
    $mergeSql = "
        MERGE INTO totalhours th
        USING (SELECT :coursename AS coursename, :currentyear AS currentyear FROM dual) new_data
        ON (th.coursename = new_data.coursename AND th.currentyear = new_data.currentyear)
        WHEN MATCHED THEN
            UPDATE SET th.hours = th.hours + :hours
        WHEN NOT MATCHED THEN
            INSERT (coursename, currentyear, attendance_date, hours)
            VALUES (:coursename, :currentyear, TO_DATE(:attendance_date, 'DD-MON-YY'), :hours)";
    
    $stmt = oci_parse($conn, $mergeSql);
    oci_bind_by_name($stmt, ':coursename', $coursename);
    oci_bind_by_name($stmt, ':currentyear', $currentyear);
    oci_bind_by_name($stmt, ':attendance_date', $date);
    oci_bind_by_name($stmt, ':hours', $hours);

    // Execute the statement
    if (oci_execute($stmt)) {
        $successMessage = "Record inserted or updated successfully!";
    } else {
        $error = oci_error($stmt);
        $errorMessage = "Insert or update failed: " . $error['message'];
    }

    // Javascript to display pop-up
    echo "<script>
            alert('" . (isset($successMessage) ? $successMessage : $errorMessage) . "');
          </script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Attendance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #00246B; /* Background color of headers */
            color: white; /* Text color of headers */
        }
        tr {
            background-color: #CADCFC; /* Row background color */
        }
        .floating-button {
            background-color: #00246B; /* Button background color */
            color: white; /* Button text color */
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 5px; /* Rounded corners */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }
        .floating-button:hover {
            background-color: #0056b3; /* Darker shade on hover */
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }
        .search-form {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <form method="post" class="search-form">
        <label for="searchTerm">Search:</label>
        <input type="text" id="searchTerm" name="searchTerm" placeholder="Enter hall ticket number or full name">
        
        <label for="coursename">Course Name:</label>
        <select id="coursename" name="coursename">
            <option value="">All Courses</option>
            <option value="CSM">CSM</option>
            <option value="CSE">CSE</option>
            <option value="CIVIL">Civil</option>
            <option value="ECE">ECE</option>
            <option value="MECH">Mech</option>
        </select>
        
        <label for="currentyear">Current Year:</label>
        <select id="currentyear" name="currentyear">
            <option value="">All Years</option>
            <option value="1st Year">1st year</option>
            <option value="2nd Year">2nd year</option>
            <option value="3rd Year">3rd year</option>
            <option value="4th Year">4th year</option>
        </select>
        
        <button type="submit" name="search" class="floating-button">Search</button>
    </form>
    
    <form method="post">
        <table>
            <thead>
                <tr>
                    <th>Hall Ticket Number</th>
                    <th>Full Name</th>
                    <th>Number of Hours <input type="text" name="hours" placeholder="Enter hours"></th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
                    echo "<tr>";
                    echo "<td>" . $row["HALLTICKETNUMBER"] . "<input type='hidden' name='hallticketnumber[]' value='" . $row["HALLTICKETNUMBER"] . "'></td>";
                    echo "<td>" . $row["FULLNAME"] . "</td>";
                    echo "<td><input type='checkbox' name='attendance[]' value='1' checked></td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
        <input type="hidden" name="coursename" value="<?php echo $selectedCourse; ?>">
        <input type="hidden" name="currentyear" value="<?php echo $selectedYear; ?>">
        <button type="submit" name="submit" class="floating-button">Submit</button>
    </form>
</body>
</html>

<?php
oci_free_statement($stid);
oci_close($conn);
?>
