<?php
// Database connection details
$host = 'localhost/XE';
$username = 'INTEGRATEDCAMPUS';
$password = '12345';

// Connect to Oracle database
$conn = oci_connect($username, $password, $host);
if (!$conn) {
    $e = oci_error();
    die("Connection failed: " . $e['message']);
}

// Query to get number of students
$sqlStudents = "SELECT COUNT(*) AS student_count FROM students";
$stmtStudents = oci_parse($conn, $sqlStudents);
oci_execute($stmtStudents);
$rowStudents = oci_fetch_assoc($stmtStudents);
$studentCount = $rowStudents['STUDENT_COUNT'];

// Query to get number of hostelers
$sqlHostelers = "SELECT COUNT(*) AS hosteler_count FROM hostelers";
$stmtHostelers = oci_parse($conn, $sqlHostelers);
oci_execute($stmtHostelers);
$rowHostelers = oci_fetch_assoc($stmtHostelers);
$hostelerCount = $rowHostelers['HOSTELER_COUNT'];

// Query to get number of books
$sqlBooks = "SELECT COUNT(*) AS book_count FROM books";
$stmtBooks = oci_parse($conn, $sqlBooks);
oci_execute($stmtBooks);
$rowBooks = oci_fetch_assoc($stmtBooks);
$bookCount = $rowBooks['BOOK_COUNT'];

// Close database connection
oci_free_statement($stmtStudents);
oci_free_statement($stmtHostelers);
oci_free_statement($stmtBooks);
oci_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            
            height: 100vh;
            background: white;
            background-size: cover;
            color: #fff;
            overflow: hidden; /* Hide overflow to prevent scrollbars */
        }
        .container {
            text-align: center;
            animation: slide-up 1s ease-out forwards; /* Animation for sliding up */
            opacity: 0; /* Start with opacity 0 */
        }
        .card {
            background: linear-gradient(to right, #11998e, #38ef7d);
            padding: 20px;
            margin: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 300px;
            display: inline-block;
            animation: fade-in 0.5s forwards; /* Animation for fading in */
            opacity: 0; /* Start with opacity 0 */
        }
        .card h2 {
            margin-bottom: 10px;
        }
        /* Keyframes for animations */
        @keyframes slide-up {
            to {
                transform: translateY(-20px); /* Slide up by 20px */
                opacity: 1; /* Fade in */
            }
        }
        @keyframes fade-in {
            to {
                opacity: 1; /* Fade in */
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h2>Number of Students</h2>
            <p><?php echo $studentCount; ?></p>
        </div>
        <div class="card">
            <h2>Number of Hostelers</h2>
            <p><?php echo $hostelerCount; ?></p>
        </div>
        <div class="card">
            <h2>Number of Books</h2>
            <p><?php echo $bookCount; ?></p>
        </div>
    </div>
</body>
</html>
