package PSAS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegratedCampusManagementSystem11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
